package client;

import service.BarberService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DepositFrame extends JFrame implements ActionListener {

    private BarberService barberService = new BarberService();

    JLabel userPhone = new JLabel("手机号:");
    JLabel count = new JLabel("充值次数:");

    // 输入
    JTextField nameField = new JTextField(15) ;
    JTextField phoneField = new JTextField(15) ;
    JTextField countField = new JTextField(15) ;

    private JButton noButton = new JButton("取消");
    private JButton yesButton = new JButton("确认");

    private Container con = this.getContentPane() ;
    public DepositFrame() {

        noButton.addActionListener(this);
        yesButton.addActionListener(this);

        this.setTitle("会员充值");
        this.setSize(300, 300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 输入框
        nameField.setEditable(true); // 设置输入框允许编辑
        phoneField.setEditable(true); // 设置输入框允许编辑
        countField.setEditable(true); // 设置输入框允许编辑

        Box boxMid2 = Box.createHorizontalBox();
        boxMid2.add(Box.createHorizontalStrut(30));
        boxMid2.add(userPhone);
        boxMid2.add(Box.createHorizontalStrut(10));
        boxMid2.add(phoneField);
        boxMid2.add(Box.createHorizontalStrut(50));

        Box boxMid3 = Box.createHorizontalBox();
        boxMid3.add(Box.createHorizontalStrut(30));
        boxMid3.add(count);
        boxMid3.add(Box.createHorizontalStrut(10));
        boxMid3.add(countField);
        boxMid3.add(Box.createHorizontalStrut(50));

        Box boxCen = Box.createVerticalBox() ;
        boxCen.add(Box.createVerticalStrut(20)) ;
        boxCen.add(boxMid2) ;
        boxCen.add(Box.createVerticalStrut(20)) ;
        boxCen.add(boxMid3) ;
        boxCen.add(Box.createVerticalStrut(40)) ;
        // 底部
        Box boxB = Box.createHorizontalBox() ;
        boxB.add(Box.createHorizontalStrut(130)) ;
        boxB.add(noButton) ;
        boxB.add(Box.createHorizontalStrut(10)) ;
        boxB.add(yesButton) ;

        con.add(boxCen);
        con.add(boxB, BorderLayout.SOUTH);

        this.setVisible(true);
    }





    @Override
    public void actionPerformed(ActionEvent ae) {

        if(ae.getSource() == yesButton){
            String phoneStr = phoneField.getText().trim();
            Long phone = Long.valueOf(phoneStr);
            String countStr = countField.getText().trim();
            Integer count = Integer.valueOf(countStr);

            barberService.deposit(phone, count);
        }

        this.dispose();
    }
}
