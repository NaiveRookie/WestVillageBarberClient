package client;

import bean.User;
import service.BarberService;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ZYBarber extends JFrame implements ActionListener {

    private JTable table = new JTable();
    private DefaultTableModel tableModel = new DefaultTableModel();
    private BarberService barberService = new BarberService();

    private JPanel jPanel;
    private JPanel tableJPanel;
    private JButton addUserButton = new JButton("会员办理");
    private JButton depositButton = new JButton("会员充值");
    private JButton haircutButton = new JButton("会员理发");
    private JTextField inputField = new JTextField();
    private JButton queryButton = new JButton("查询");

    private Container con = this.getContentPane(); // 内容面板

    private String[] strName = new String[]{"会员编号", "会员名称", "会员电话",
            "剩余次数", "最近充值", "最近理发", "注册日期"};

    public ZYBarber() {
        jPanel = new JPanel();
        tableJPanel = new JPanel();
        this.setTitle("会员管理");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // 输入框
        inputField.setEditable(true); // 设置输入框允许编辑
        inputField.setColumns(15); // 设置输入框的长度为11个字符
        addUserButton.addActionListener(this);
        depositButton.addActionListener(this);
        haircutButton.addActionListener(this);
        queryButton.addActionListener(this);
        // 会员办理按钮
        jPanel.add(addUserButton);
        jPanel.add(depositButton);
        jPanel.add(haircutButton);
        jPanel.add(inputField);
        jPanel.add(queryButton);

        // 表格
        for (int i = 0; i < strName.length; i++) {
            tableModel.addColumn(strName[i]);
        }

        table.setModel(tableModel);
        JScrollPane jsp = new JScrollPane();
        jsp.setViewportView(table);

//        TableColumnModel columnModel = table.getColumnModel();
//        columnModel.getColumn(0).setPreferredWidth(80);
//        columnModel.getColumn(1).setPreferredWidth(80);
//        columnModel.getColumn(2).setPreferredWidth(150);
//        columnModel.getColumn(3).setPreferredWidth(80);
//        columnModel.getColumn(4).setPreferredWidth(150);
//        columnModel.getColumn(5).setPreferredWidth(150);
//        columnModel.getColumn(6).setPreferredWidth(150);

        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();//单元格渲染器
        tcr.setHorizontalAlignment(JLabel.CENTER);//居中显示
        jPanel.setSize(100, 100);
        table.setDefaultRenderer(Object.class, tcr);//设置渲染器
        table.setSize(400,300);
        tableJPanel.add(jsp);
        this.add(jPanel);
        this.add(tableJPanel);
        this.setLayout(new FlowLayout());
        this.setVisible(true);

    }


    public static void main(String[] args) {
        ZYBarber zyBarber = new ZYBarber();
        zyBarber.setSize(600, 500);
    }


    private void query() {
        String searchKey = inputField.getText().trim();
        List<User> users = barberService.queryUser(searchKey);
        // 清空原来记录
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
        for (User user : users) {
//                {"会员编号", "会员名称", "会员电话",
//                        "剩余次数", "最近充值", "最近理发", "注册日期"}
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Object[] row = new Object[8];
            row[0] = user.getId();
            if (user.getName() != null) {
                row[1] = user.getName();
            }
            if (user.getPhoneNumber() != null) {
                row[2] = user.getPhoneNumber();
            }
            row[3] = user.getCount();
            Date recentDepositTime = user.getRecentDepositTime();
            if (user.getRecentDepositTime() != null) {
                row[4] = format.format(recentDepositTime);
            }
            if (user.getRecentHaircutTime() != null) {
                Date recentHaircutTime = user.getRecentHaircutTime();
                row[5] = format.format(recentHaircutTime);
            }
            row[6] = format.format(user.getCreated());
            tableModel.addRow(row);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == queryButton) {
            query();
        } else if (e.getSource() == addUserButton) {
            AddUserFrame addUserFrame = new AddUserFrame();
            addUserFrame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    query();
                }
            });
            addUserFrame.setVisible(true);
        } else if (e.getSource() == haircutButton) {
            HaircutFrame haircutFrame = new HaircutFrame();
            haircutFrame.setVisible(true);
            haircutFrame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    query();
                }
            });
        } else if (e.getSource() == depositButton) {
            DepositFrame depositFrame = new DepositFrame();
            depositFrame.setVisible(true);
            depositFrame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    query();
                }
            });
        }
    }
}
