package bean;

import java.util.Date;

/**
 * 会员信息
 */
public class User {

    public User() {
    }

    private Integer id;
    private Long phoneNumber;
    private String name; // 名称
    private Date recentDepositTime; // 最近充值时间
    private Date recentHaircutTime; // 最近理发时间
    private Date created; // 创建时间(办理会员时间)
    private Integer count; // 剩余次数
    private Integer consumptionMoney; // 累计消费金额
    private Date modified; // 修改时间(方便排序)

    public Date getRecentDepositTime() {
        return recentDepositTime;
    }

    public void setRecentDepositTime(Date recentDepositTime) {
        this.recentDepositTime = recentDepositTime;
    }

    public Date getRecentHaircutTime() {
        return recentHaircutTime;
    }

    public void setRecentHaircutTime(Date recentHaircutTime) {
        this.recentHaircutTime = recentHaircutTime;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getConsumptionMoney() {
        return consumptionMoney;
    }

    public void setConsumptionMoney(Integer consumptionMoney) {
        this.consumptionMoney = consumptionMoney;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }
}
