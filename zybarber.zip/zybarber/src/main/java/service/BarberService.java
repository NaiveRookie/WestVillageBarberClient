package service;

import db.Database;
import bean.User;

import javax.swing.*;
import java.util.List;

public class BarberService {

    private Database database = new Database();

    public BarberService() {

    }

    public List<User> queryUser(String searchKey) {
        List<User> users = database.getUsers(searchKey);
        return users;
    }

    public void hairCut(Long phone, Integer count) {
        if (phone == null || count == null) {
            JOptionPane.showMessageDialog(null, "无效操作,请检查操作");
        }
        User user = database.getUserByPhone(phone);
        if (user == null) {
            JOptionPane.showMessageDialog(null, "该用户不存在(非会员).");
            return;
        }
        int restCount = user.getCount();
        if (count > restCount) {
            JOptionPane.showMessageDialog(null, "该会员的剩余次数为:" + restCount + "无法进行本次消费");
            return;
        }
        database.haircut(phone, count);
        JOptionPane.showMessageDialog(null, "操作成功,手机号为:" + phone + "的用户目前剩余次数为:" + (restCount - count));
    }

    /**
     * 充值
     */
    public void deposit(Long phone, Integer count) {
        if (phone == null || count == null) {
            JOptionPane.showMessageDialog(null, "无效操作,请检查操作");
        }
        User user = database.getUserByPhone(phone);
        if (user == null) {
            JOptionPane.showMessageDialog(null, "操作成功,手机号为:" + phone + "的用户目前剩余次数为:" + (count));
            return;
        } else {
            int restCount = user.getCount();
            database.deposit(phone, count);
            JOptionPane.showMessageDialog(null, "操作成功,手机号为:" + phone + "的用户目前剩余次数为:" + (count + restCount));
            return;
        }
    }

    public void addVip(Long phone, Integer count, String name) {
        if (phone == null || count == null) {
            JOptionPane.showMessageDialog(null, "无效操作,请检查操作");
        }
        User user = database.getUserByPhone(phone);
        if (user == null) {
            database.addUser(name, phone, count);
            JOptionPane.showMessageDialog(null, "操作成功,手机号为:" + phone + "的用户目前剩余次数为:" + (count));
            return;
        } else {
            int restCount = user.getCount();
            database.deposit(phone, count);
            JOptionPane.showMessageDialog(null, "操作成功,手机号为:" + phone + "的用户目前剩余次数为:" + (count + restCount));
            return;
        }
    }

}
