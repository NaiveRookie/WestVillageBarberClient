package db;

import bean.User;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;


public class Database {

    private Connection con = null;
    private String driver = "com.mysql.jdbc.Driver";
    private String url = "jdbc:mysql://localhost:3306/zy_barber?useUnicode=true&characterEncoding=utf-8";

    public Database() {
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, "root", "123456");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    //�õ����ݿ�����
    public Connection getCon() {
        if (con == null) {
            JOptionPane.showMessageDialog(null, "链接失败");
            return null;
        } else {
            return con;
        }
    }

    public List<User> getUsers(String input) {
        List<User> res = new ArrayList<>();

        String sql = getQuerySql(input);
        ResultSet rs = exeSelect(sql);
        try {
            while (rs.next()) {
                User user = fixRs(rs);
                res.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return res;
    }

    private User fixRs(ResultSet rs) {
        User user = new User();
        try {
            Optional.ofNullable(rs.getInt(1)).ifPresent(user::setId);
            Optional.ofNullable(rs.getLong(2)).ifPresent(user::setPhoneNumber);
            Optional.ofNullable(rs.getString(3)).ifPresent(user::setName);
            Optional.ofNullable(rs.getTimestamp(4)).map(Timestamp::getTime).map(Date::new).ifPresent(user::setRecentDepositTime);
            Optional.ofNullable(rs.getTimestamp(5)).map(Timestamp::getTime).map(Date::new).ifPresent(user::setRecentHaircutTime);
            user.setCreated(new Date(rs.getTimestamp(6).getTime()));
            user.setCount(rs.getInt(7));
            user.setConsumptionMoney(rs.getInt(8));
            user.setModified(new Date(rs.getTimestamp(9).getTime()));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    public void addUser(String name, Long phoneNumber, Integer count) {
        String sql = "insert into barber_user (`name`, recent_deposit_time, phone_number, created, count, modified ) values" +
                "('" + name + "', now(), " + phoneNumber + ",now(), " + count + ", now())";
        exeSql(sql);
    }

    public void haircut(Long phoneNumber, Integer count) {
        String sql = "update barber_user set count = count - " + count + ", recent_haircut_time = now() " + ",modified = now() "
                + " where phone_number = " + phoneNumber;
        exeSql(sql);
    }

    public void deposit(Long phoneNumber, Integer count) {
        String sql = "update barber_user set count = count + " + count + ", recent_deposit_time = now() " + ",modified = now() "
                + " where phone_number = " + phoneNumber;
        exeSql(sql);
    }

    private String getQuerySql(String input) {
        String sql = "";
        if (input != null && input.trim().length() > 0) {
            sql = "select id, phone_number, name, recent_deposit_time, recent_haircut_time, created, count, consumption_money, modified " +
                    "from zy_barber.barber_user where " +
                    "barber_user.phone_number LIKE CONCAT('%','" + input + "','%') " +
                    "OR barber_user.name LIKE CONCAT('%','" + input + "','%')" +
                    " order by modified desc limit 100";
        } else {
            sql = "select * from zy_barber.barber_user order by modified desc limit 100";
        }
        System.out.println(sql);
        return sql;
    }

    public User getUserByPhone(Long phone) {
        String sql = "select id, phone_number, name, recent_deposit_time, recent_haircut_time, created, count, consumption_money, modified from barber_user where phone_number =" + phone;
        ResultSet rs = exeSelect(sql);
        try {
            if (rs.next()) {
                User user = fixRs(rs);
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ResultSet exeSelect(String sql) {
        ResultSet rs = null;
        Statement stm = null;
        try {
            stm = con.createStatement();
            rs = stm.executeQuery(sql);
            return rs;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return rs;
    }

    public boolean exeSql(String sql) {
        boolean flag = false;
        Statement stm = null;
        try {
            stm = con.createStatement();
            int exeNum = stm.executeUpdate(sql);

            if (exeNum > 0) {
                flag = true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return flag;
    }
}

